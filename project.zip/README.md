This is auto solution web project
